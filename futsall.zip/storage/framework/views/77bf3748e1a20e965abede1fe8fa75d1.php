<form action="<?php echo e($action); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($method === 'PUT'): ?>
        <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    <div class="form-group">
        <label for="field_id">Pilih Lapangan</label>
        <select name="field_id" class="form-control" required>
            <option value="">-- Pilih --</option>
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($field->id); ?>"
                    <?php if(old('field_id', $schedule->field_id ?? '') == $field->id): ?> selected <?php endif; ?>>
                    <?php echo e($field->nama); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="day_of_week">Hari</label>
        <input type="text" name="day_of_week" class="form-control" value="<?php echo e(old('day_of_week', $schedule->day_of_week ?? '')); ?>" required>
    </div>

    <div class="form-group">
        <label for="start_time">Jam Mulai</label>
        <input type="time" name="start_time" class="form-control" value="<?php echo e(old('start_time', $schedule->start_time ?? '')); ?>" required>
    </div>

    <div class="form-group">
        <label for="end_time">Jam Selesai</label>
        <input type="time" name="end_time" class="form-control" value="<?php echo e(old('end_time', $schedule->end_time ?? '')); ?>" required>
    </div>

    <div class="form-group">
        <label for="is_available">Tersedia?</label>
        <select name="is_available" class="form-control" required>
            <option value="1" <?php echo e(old('is_available', $schedule->is_available ?? '') == 1 ? 'selected' : ''); ?>>Ya</option>
            <option value="0" <?php echo e(old('is_available', $schedule->is_available ?? '') == 0 ? 'selected' : ''); ?>>Tidak</option>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Simpan</button>
    <a href="<?php echo e(route('admin.schedules.index')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php /**PATH C:\laragon\www\futsal\resources\views/admin/schedules/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Daftar Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title mb-0">Daftar Booking</h3>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="mb-3 text-right">
                <a href="<?php echo e(route('admin.bookings.create')); ?>" class="btn btn-primary rounded shadow-sm">
                    <i class="fas fa-plus"></i> Tambah Booking
                </a>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Pengguna</th>
                        <th>Lapangan</th>
                        <th>Tanggal</th>
                        <th>Jam</th>
                        <th>Status</th>
                        <th>Total Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($booking->user->name ?? '-'); ?></td>
                            <td><?php echo e($booking->field->nama ?? '-'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($booking->tanggal_pemesanan)->translatedFormat('d F Y')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($booking->start_time)->format('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($booking->end_time)->format('H:i')); ?></td>
                            <td>
                                <?php
                                    $status = ucfirst($booking->status);
                                    $styles = [
                                        'Pending' => 'background-color: #fef9c3; color: #92400e;',   // kuning muda
                                        'Confirmed' => 'background-color: #bbf7d0; color: #166534;', // hijau muda
                                        'Failed' => 'background-color: #fecaca; color: #991b1b;', // merah muda
                                    ];
                                    $style = $styles[$status] ?? 'background-color: #e5e7eb; color: #374151;'; // abu
                                ?>

                                <span style="padding: 4px 8px; font-size: 0.875rem; font-weight: 500; border-radius: 0.375rem; <?php echo e($style); ?>">
                                    <?php echo e($status); ?>

                                </span>
                            </td>

                            <td>Rp <?php echo e(number_format($booking->total_harga, 0, ',', '.')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.bookings.edit', $booking->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.bookings.destroy', $booking->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus booking ini?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">Belum ada data booking.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\futsal\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>
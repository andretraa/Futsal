
<?php $__env->startSection('title', 'Edit Booking'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Edit Booking</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.bookings.update', $booking->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="field_id">Pilih Lapangan</label>
                    <select name="field_id" class="form-control" required>
                        <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($field->id); ?>" <?php echo e($booking->field_id == $field->id ? 'selected' : ''); ?>>
                                <?php echo e($field->nama); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="schedule_id">Pilih Jadwal</label>
                    <select name="schedule_id" class="form-control" required>
                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($schedule->id); ?>"
                                <?php echo e($booking->start_time == $schedule->start_time && $booking->end_time == $schedule->end_time ? 'selected' : ''); ?>>
                                <?php echo e($schedule->field->nama); ?> - <?php echo e(ucfirst($schedule->day_of_week)); ?> (<?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="tanggal_pemesanan">Tanggal Pemesanan</label>
                    <input type="date" name="tanggal_pemesanan" class="form-control"
                           value="<?php echo e(\Carbon\Carbon::parse($booking->tanggal_pemesanan)->format('Y-m-d')); ?>" required>
                </div>

                <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" class="form-control" required>
                        <option value="pending" <?php echo e($booking->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="confirmed" <?php echo e($booking->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
                        <option value="cancelled" <?php echo e($booking->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="total_harga">Total Harga</label>
                    <input type="number" name="total_harga" class="form-control"
                           value="<?php echo e($booking->total_harga); ?>" required>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-secondary">Batal</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\futsal\resources\views/admin/bookings/edit.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Jadwal Lapangan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Daftar Jadwal</h3>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="mb-3 text-right">
                <a href="<?php echo e(route('admin.schedules.create')); ?>" class="btn btn-primary rounded shadow-sm">
                    <i class="fas fa-plus"></i>Tambah Jadwal
                </a>
            </div>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Lapangan</th>
                        <th>Hari</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($schedule->field->nama); ?></td>
                            <td><?php echo e($schedule->day_of_week); ?></td>
                            <td><?php echo e($schedule->start_time); ?></td>
                            <td><?php echo e($schedule->end_time); ?></td>
                            <td><?php echo e($schedule->is_available ? 'Tersedia' : 'Tidak Tersedia'); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.schedules.edit', $schedule->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.schedules.destroy', $schedule->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Hapus jadwal ini?')">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($schedules->isEmpty()): ?>
                        <tr>
                            <td colspan="6" class="text-center">Belum ada jadwal</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\futsal\resources\views/admin/schedules/index.blade.php ENDPATH**/ ?>
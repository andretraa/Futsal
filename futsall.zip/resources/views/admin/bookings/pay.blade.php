{{-- resources/views/admin/bookings/pay.blade.php --}}
@extends('admin.layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Pembayaran Booking</div>

                <div class="card-body">
                    <h5>Detail Pemesanan:</h5>
                    <table class="table table-bordered">
                        <tr>
                            <th>ID Pemesanan</th>
                            <td>{{ $booking->id }}</td>
                        </tr>
                        <tr>
                            <th>Lapangan</th>
                            <td>{{ $booking->field->nama }}</td>
                        </tr>
                        <tr>
                            <th>Tanggal</th>
                            <td>{{ $booking->tanggal_pemesanan }}</td>
                        </tr>
                        <tr>
                            <th>Waktu</th>
                            <td>{{ Carbon\Carbon::parse($booking->start_time)->format('H:i') }} - {{ Carbon\Carbon::parse($booking->end_time)->format('H:i') }}</td>
                        </tr>
                        <tr>
                            <th>Total Harga</th>
                            <td>Rp {{ number_format($booking->total_harga, 0, ',', '.') }}</td>
                        </tr>
                    </table>

                    <div class="text-center mt-4">
                        <button id="pay-button" class="btn btn-primary">Bayar Sekarang</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="{{ config('midtrans.client_key') }}"></script>
<script>
    document.getElementById('pay-button').onclick = function() {
        // Trigger snap popup
        snap.pay('{{ $snapToken }}', {
            onSuccess: function(result) {
                window.location.href = '{{ route('booking.finish', $booking->id) }}';
            },
            onPending: function(result) {
                window.location.href = '{{ route('booking.pending', $booking->id) }}';
            },
            onError: function(result) {
                window.location.href = '{{ route('booking.error', $booking->id) }}';
            },
            onClose: function() {
                alert('Anda menutup popup tanpa menyelesaikan pembayaran');
            }
        });
    };
</script>
@endpush